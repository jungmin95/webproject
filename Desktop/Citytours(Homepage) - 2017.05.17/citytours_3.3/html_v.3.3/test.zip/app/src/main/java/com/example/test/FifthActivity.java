package com.example.test;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class FifthActivity extends AppCompatActivity {

    Button btn5ok, btn5no;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth);

        btn5ok=(Button)findViewById(R.id.btn5ok);
        btn5no=(Button)findViewById(R.id.btn5no);

        btn5ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SixthActivity.class);
                startActivity(intent);

            }
        });
        btn5no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"야레야레",Toast.LENGTH_LONG).show();

            }
        });
    }
}
